<?php
/*
Plugin Name: WP Any Post Widget
Plugin URI: http://themeaxe.com/
Description: This plugin will help you to use any custom post or page list as widget.
Version: 1.1.1
Author: Md. Hasan Shahriar
Author URI: http://github.com/hsleonis
License: GPLv2 or later
Text Domain: themeaxe
*/
/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2017 ThemeAxe.
*/

defined('WPAPW_URL') or define('WPAPW_URL', plugin_dir_url(__FILE__));

require_once('inc/WPAnyPost.php');
require_once('inc/WPLoginWidget.php');
require_once('inc/WPSinglePost.php');
require_once('inc/WPAuthorInfo.php');
require_once('inc/WPMediaWidget.php');
require_once('inc/WPVideoWidget.php');

add_action( 'widgets_init', function(){
    register_widget( 'ThemeAxe\WPAnyPost' );
    register_widget( 'ThemeAxe\WPLoginWidget' );
    register_widget( 'ThemeAxe\WPSinglePost' );
    register_widget( 'ThemeAxe\WPAuthorInfo' );
    register_widget( 'ThemeAxe\WPMediaWidget' );
    register_widget( 'ThemeAxe\WPVideoWidget' );
});