/**
 * Media explorer
 * Author: Md. Hasan Shahriar
 * Date: 15/3/2016
 * themeaxe@gmail.com
 */

(function () {
    "use strict";

    jQuery( document ).ready( function( $ ) {
        // Uploading files
        var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id

        jQuery(document).on('click', '.upload-image-button', function( event ){
            event.preventDefault();

            var button = $(this);
            var widget = button.parent();
            var set_to_post_id = button.data('id'); // Set this

            // Set the wp.media post id so the uploader grabs the ID we want when initialised
            wp.media.model.settings.post.id = set_to_post_id;

            // Create the media frame.
            var file_frame = wp.media.frames.file_frame = wp.media({
                title: 'Select a image to upload',
                button: {
                    text: 'Use this image'
                },
                multiple: false	// Set to true to allow multiple files to be selected
            });

            // When an image is selected, run a callback.
            file_frame.on( 'select', function() {
                // We set multiple to false so only get one image from the uploader
                var attachment = file_frame.state().get('selection').first().toJSON();

                // Do something with attachment.id and/or attachment.url here
                if(attachment.id) {
                    widget.find('.image-preview').attr('src', attachment.sizes.thumbnail.url);
                    widget.find('.image-preview-wrapper, .remove-image-button').show();
                    widget.find('.image-attachment-id').val(attachment.id);
                    widget.find('.tap-attachment input').val(attachment.url);
                    button.attr('data-id', attachment.id);
                }

                // Restore the main post ID
                wp.media.model.settings.post.id = set_to_post_id;
            });
            // Finally, open the modal
            file_frame.open();
        });

        // Remove Image
        jQuery(document).on('click', '.remove-image-button', function( event ) {
            event.preventDefault();
            var widget = $(this).parent();

            widget.find('.image-preview').attr( 'src', '' );
            widget.find('.image-preview-wrapper, .remove-image-button' ).hide();
            widget.find('.image-attachment-id' ).val( '0' );
            widget.find('.tap-attachment input').val( '' );
            $(this).attr( 'data-id', '0' );
        });

        // Restore the main ID when the add media button is pressed
        jQuery(document).on('click', 'a.add_media', function( event ) {
            wp.media.model.settings.post.id = wp_media_post_id;
        });
    });
    
}());