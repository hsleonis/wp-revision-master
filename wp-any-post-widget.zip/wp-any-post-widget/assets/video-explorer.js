/**
 * Video explorer
 * Author: Md. Hasan Shahriar
 * Date: 16/3/2016
 * themeaxe@gmail.com
 */

(function () {
    "use strict";

    jQuery( document ).ready( function( $ ) {
        // Uploading files
        var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id

        jQuery(document).on('click', '.upload-video-button', function( event ){
            event.preventDefault();

            var button = $(this);
            var widget = button.parent();
            var set_to_post_id = button.data('id'); // Set this

            // Set the wp.media post id so the uploader grabs the ID we want when initialised
            wp.media.model.settings.post.id = set_to_post_id;

            // Create the media frame.
            var file_frame = wp.media.frames.file_frame = wp.media({
                title: 'Select a video to upload',
                button: {
                    text: 'Use this video'
                },
                multiple: false,	// Set to true to allow multiple files to be selected
                library: { type : 'video' }
            });

            // When a video is selected, run a callback.
            file_frame.on( 'select', function() {
                // We set multiple to false so only get one video from the uploader
                var attachment = file_frame.state().get('selection').first().toJSON();

                // Do something with attachment.id and/or attachment.url here
                if(attachment.id) {
                    console.log(attachment);
                    widget.find('.video-preview-wrapper, .remove-video-button').show();
                    widget.find('.video-attachment-id').val(attachment.id);
                    widget.find('.tap-attachment input').val(attachment.url);
                    button.attr('data-id', attachment.id);
                }

                // Restore the main post ID
                wp.media.model.settings.post.id = set_to_post_id;
            });
            // Finally, open the modal
            file_frame.open();
        });

        // Remove Video
        jQuery(document).on('click', '.remove-video-button', function( event ) {
            event.preventDefault();
            var widget = $(this).parent();

            widget.find('.video-preview-wrapper, .remove-video-button' ).hide();
            widget.find('.video-attachment-id' ).val( '0' );
            widget.find('.tap-attachment input').val( '' );
            $(this).attr( 'data-id', '0' );
        });

        // Restore the main ID when the add media button is pressed
        jQuery(document).on('click', 'a.add_media', function( event ) {
            wp.media.model.settings.post.id = wp_media_post_id;
        });
    });
    
}());