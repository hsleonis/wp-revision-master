<?php

namespace Themeaxe;

/**
 * Class WPMediaWidget
 * @package Themeaxe
 */
class WPMediaWidget extends \WP_Widget {

    /**
     * WPMediaWidget constructor.
     */
    function __construct() {
        $widget_ops = array(
            'classname' => 'wp_media_widget',
            'description' => __( 'Show any media', 'themeaxe' ),
        );
        parent::__construct( 'wp_media_widget', __('Media', 'themeaxe' ), $widget_ops  );

        add_action('admin_enqueue_scripts', array($this, 'enqueue'));
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];

        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }

        $height = ($instance['height']=='auto')?$instance['height']: intval($instance['height']);
        $width = ($instance['width']=='auto')?$instance['width']: intval($instance['width']);

        // View
        if($instance['attachment']!==''):
            if($instance['action']!==''): ?>
                <a href="<?php echo esc_url($instance['link']); ?>" target="<?php esc_attr_e($instance['action']); ?>">
            <?php endif; ?>

                <img src="<?php esc_attr_e($instance['attachment']); ?>" title="<?php esc_attr_e($instance['caption']); ?>" height="<?php esc_attr_e($height); ?>" width="<?php esc_attr_e($width); ?>" />

            <?php if($instance['action']!==''): ?>
                </a>
        <?php endif; endif; ?>

        <?php if($instance['caption']!==''): ?>
            <div class="wp-media-widget-caption">
                <?php esc_html_e($instance['caption']); ?>
            </div>
        <?php endif; ?>

        <?php if($instance['description']!==''): ?>
            <div class="wp-media-widget-description">
                <?php esc_html_e($instance['description']); ?>
            </div>
        <?php endif; ?>

        <?php
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     *
     * @return void
     */
    public function form( $instance ) {

        $attachment     = ! empty( $instance['attachment'] ) ? $instance['attachment'] : '';
        $attachment_ID  = ! empty( $instance['attachment_ID'] ) ? $instance['attachment_ID'] : '';
        $action         = ! empty( $instance['action'] ) ? $instance['action'] : '';

        $action_list = array(
            '_self'     => 'Current tab',
            '_blank'    => 'New tab',
            '_top'      => 'New window',
            ''          => 'None'
        );
        ?>
        <!-- Widget title -->
        <?php $this->text($instance, 'Title', 'title'); ?>

        <!-- Media -->
        <div class='image-preview-wrapper' <?php if(!$attachment) echo "style='display:none;'"; ?>>
            <img class='image-preview' src='<?php echo esc_url($attachment); ?>' style='max-height: 150px; max-width: 200px;'>
        </div>
        <input data-id="<?php esc_attr_e($attachment_ID); ?>" type="button" class="upload-image-button button" value="<?php _e( 'Add Image', 'themeaxe' ); ?>" />
        <input <?php if(!$attachment) echo "style='display:none;'"; ?> type="button" class="remove-image-button button" value="<?php _e( 'Remove', 'themeaxe' ); ?>" />
        <input class="widefat image-attachment-id" id="<?php esc_attr_e($this->get_field_id( 'attachment_ID' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'attachment_ID' )); ?>" type="hidden" value="<?php echo esc_attr( $attachment_ID ); ?>">

        <!-- Fields -->
        <?php
        $this->text($instance, 'URL', 'attachment');
        $this->text($instance, 'Caption', 'caption');
        $this->text($instance, 'Height', 'height', '250');
        $this->text($instance, 'Width', 'width', '250');
        $this->text($instance, 'Description', 'description');
        $this->text($instance, 'Action link', 'link');
        ?>

        <!-- Link open -->
        <p class="tap-orderby">
            <label for="<?php esc_attr_e($this->get_field_id( 'action' )); ?>">
                <?php _e( 'Open link in:', 'themeaxe' ); ?>
            </label>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( 'action' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'action' )); ?>">
                <?php foreach ($action_list as $key=>$val): ?>
                    <option value="<?php esc_attr_e($key); ?>" <?php selected( $key, $action ); ?>>
                        <?php esc_html_e($val); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <?php
    }

    /**
     * Text field in widgets
     * @param $label
     * @param $field
     * @param $default
     */
    public function text($instance, $label, $field, $default=''){
        $value = ! empty( $instance[$field] ) ? $instance[$field] : $default;
        ?>
        <p class="tap-<?php echo $field; ?>">
            <label for="<?php esc_attr_e($this->get_field_id( $field )); ?>">
                <?php _e( $label.':', 'themeaxe' ); ?>
            </label>
            <input class="widefat" id="<?php esc_attr_e($this->get_field_id( $field )); ?>" name="<?php esc_attr_e($this->get_field_name( $field )); ?>" type="text" value="<?php echo esc_attr( $value ); ?>">
        </p>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $fields = array('title', 'attachment', 'attachment_ID','caption','height', 'width', 'description', 'link', 'action');

        foreach ($fields as $field) {
            $instance[$field] = (!empty($new_instance[$field])) ? strip_tags($new_instance[$field]) : '';
        }

        return $instance;
    }

    /**
     * Enqueue media
     */
    public function enqueue($hook){
        if($hook=='widgets.php'){
            wp_enqueue_media();
            wp_enqueue_script( 'media-explorer', WPAPW_URL.'assets/media-explorer.js' );
        }
    }
}