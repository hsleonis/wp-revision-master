<?php

namespace Themeaxe;

/**
 * Class WPAuthorInfo
 * @package Themeaxe
 */
class WPAuthorInfo extends \WP_Widget {

    /**
     * WPAnyPost constructor.
     */
    function __construct() {
        $widget_ops = array(
            'classname' => 'wp_author_info',
            'description' => __( 'Show any user profile', 'themeaxe' ),
        );
        parent::__construct( 'wp_author_info', __('Author', 'themeaxe' ), $widget_ops  );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];

        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ). $args['after_title'];
        }

        $this->author($instance);

        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     *
     * @return void
     */
    public function form( $instance ) {
        $title              = ! empty( $instance['title'] ) ? $instance['title'] : __( '', 'themeaxe' );
        $author             = ! empty( $instance['author'] ) ? $instance['author'] : '';
        $author_posts       = ! empty( $instance['author_posts'] ) ? $instance['author_posts'] : 1;
        $show_avatar        = (bool) $instance['show_avatar'];
        $show_name          = (bool) $instance['show_name'];
        $show_bio           = (bool) $instance['show_bio'];
        $show_member        = (bool) $instance['show_member'];
        $show_posts         = (bool) $instance['show_posts'];
        $show_total         = (bool) $instance['show_total'];
        $show_web           = (bool) $instance['show_web'];

        ?>
        <!-- Widget title -->
        <p class="tap-title">
            <label for="<?php esc_attr_e($this->get_field_id( 'title' )); ?>">
                <?php _e( 'Title:', 'themeaxe' ); ?>
            </label>
            <input class="widefat" id="<?php esc_attr_e($this->get_field_id( 'title' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <!-- User -->
        <p class="tap-user">
            <label for="<?php esc_attr_e($this->get_field_id( 'author' )); ?>">
                <?php _e( 'User:', 'themeaxe' ); ?>
            </label>
            <?php
            $blogusers = get_users( array(
                'fields' => array( 'ID', 'display_name' )
            ) );
            ?>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( 'author' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'author' )); ?>">
                <?php foreach ($blogusers as $user): ?>
                    <option value="<?php esc_attr_e($user->ID); ?>" <?php selected( $user->ID, $author ); ?>>
                        <?php esc_html_e($user->display_name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <!-- Description -->
        <p class="tap-description">
            <strong><?php _e( 'Select elements to show.', 'themeaxe' ); ?></strong>
        </p>

        <!-- Avatar -->
        <p class="tap-avatar">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_avatar' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_avatar' )); ?>" type="checkbox" value="<?php echo $show_avatar; ?>" <?php checked($show_avatar); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_avatar' )); ?>">
                <?php _e( 'Avatar', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Name -->
        <p class="tap-name">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_name' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_name' )); ?>" type="checkbox" value="<?php echo $show_name; ?>" <?php checked($show_name); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_name' )); ?>">
                <?php _e( 'Name', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Bio -->
        <p class="tap-bio">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_bio' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_bio' )); ?>" type="checkbox" value="<?php echo $show_bio; ?>" <?php checked($show_bio); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_bio' )); ?>">
                <?php _e( 'Bio', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Member since -->
        <p class="tap-member">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_member' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_member' )); ?>" type="checkbox" value="<?php echo $show_member; ?>" <?php checked($show_member); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_member' )); ?>">
                <?php _e( 'Show user registration', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Total posts -->
        <p class="tap-total">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_total' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_total' )); ?>" type="checkbox" value="<?php echo $show_total; ?>" <?php checked($show_total); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_total' )); ?>">
                <?php _e( 'Show Total Posts', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Website -->
        <p class="tap-web">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_web' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_web' )); ?>" type="checkbox" value="<?php echo $show_web; ?>" <?php checked($show_web); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_web' )); ?>">
                <?php _e( 'Show Web Link', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Description -->
        <p class="tap-description">
            <strong><?php _e( 'User posts', 'themeaxe' ); ?></strong>
        </p>

        <!-- Show posts -->
        <p class="tap-posts">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_posts' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_posts' )); ?>" type="checkbox" value="<?php echo $show_posts; ?>" <?php checked($show_posts); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_posts' )); ?>">
                <?php _e( 'Show posts', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Number of posts to show -->
        <p class="tap-author-posts">
            <label for="<?php esc_attr_e($this->get_field_id( 'author_posts' )); ?>">
                <?php _e( 'Number of posts to show:', 'themeaxe' ); ?>
            </label>
            <input class="widefat" id="<?php esc_attr_e($this->get_field_id( 'author_posts' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'author_posts' )); ?>" min="-1" max="25" type="number" value="<?php esc_attr_e( $author_posts ); ?>">
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();

        $fields = array('title','author','author_posts');
        foreach ($fields as $field) {
            $instance[$field] = (!empty($new_instance[$field])) ? strip_tags($new_instance[$field]) : '';
        }

        $fields = array('show_avatar','show_name','show_bio','show_member','show_posts','show_total','show_web');
        foreach ($fields as $field) {
            $instance[$field] = isset($new_instance[$field])?true:false;
        }

        return $instance;
    }

    /**
     * Author Information
     * @param $data Instance
     */
    public function author($data){
        // Get post by ID
        $author_id = $data['author'];
        $author = get_user_by('id', $author_id);

        // The post
        if ( $author_id): ?>
            <div class="wp-author-info">
                <?php if($data['show_avatar']): ?>
                    <div class="author-avatar">
                        <img class="media-object" src="<?php echo get_avatar_url( $author_id, '300x300' ); ?>" />
                    </div>
                <?php endif; ?>
                <?php if($data['show_name']): ?>
                    <div class="author-name">
                        <a href="<?php echo get_author_posts_url( $author_id ); ?>">
                            <?php esc_attr_e($author->display_name); ?>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($data['show_bio']): ?>
                    <div class="author-bio">
                        <?php echo nl2br($author->description); ?>
                    </div>
                <?php endif; ?>

                <div class="author-stats">
                    <ul>
                        <?php if($data['show_member']): ?>
                        <li><?php _e('Member since', 'themeaxe'); ?> &colon; <?php echo human_time_diff( strtotime($author->user_registered), current_time('timestamp') ); ?></li>
                        <?php endif; ?>
                        <?php if($data['show_total']): ?>
                        <li><?php _e('Total posts', 'themeaxe'); ?> &colon; <?php echo count_user_posts( $author_id ); ?></li>
                        <?php endif; ?>
                        <?php if($data['show_web']): ?>
                        <li><?php _e('Website', 'themeaxe'); ?> &colon; <a href="<?php echo $author->user_url; ?>" target="_blank" title="<?php _e('Author website', 'themeaxe'); ?>"><?php echo $author->user_url; ?></a></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <?php if($data['show_posts']): ?>
                <div class="author-posts">
                    <h4><?php _e('Recent posts by','themeaxe'); ?> <?php esc_attr_e($author->display_name); ?></h4>
                    <?php $this->anyposts(array(
                        'post_type'      => 'any',
                        'author'         => $author_id,
                        'posts_per_page' => $data['author_posts']
                    )); ?>
                </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p>
                <?php _e("Author not found.", "themeaxe"); ?>
            </p>
        <?php endif;
    }

    /**
     * Post type loop
     * @param $args WP_query objecct
     */
    public function anyposts($args){
        // The Query
        $query = new \WP_Query( $args );

        // The Loop
        if ( $query->have_posts() ): ?>
            <ul class="wp-any-post-list">
                <?php while ( $query->have_posts() ): $query->the_post(); ?>
                    <li>
                        <a href='<?php the_permalink(); ?>'>
                            <?php
                                the_post_thumbnail('thumbnail', ['class' => 'img-responsive wp-any-post-thumbnail', 'title' => get_the_title()]);
                            ?>
                            <div class="post-title"><?php the_title(); ?></div>
                        </a>
                        <div class="post-date"><?php echo get_the_date('j M, Y'); ?></div>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>
                <?php _e("No posts found.", "themeaxe"); ?>
            </p>
        <?php endif;

        // Restore original Post Data
        wp_reset_postdata();
    }

}