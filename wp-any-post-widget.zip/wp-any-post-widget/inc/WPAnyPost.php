<?php

namespace Themeaxe;

/**
 * Class TmxAnyPost
 * @package Themeaxe
 */
class WPAnyPost extends \WP_Widget {

    /**
     * WPAnyPost constructor.
     */
    function __construct() {
        $widget_ops = array(
            'classname' => 'wp_any_post',
            'description' => __( 'Show any custom post or page list', 'themeaxe' ),
        );
        parent::__construct( 'wp_any_post', __('Any Post', 'themeaxe' ), $widget_ops  );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];

        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ). $args['after_title'];
        }

        $query = array(
            'post_type'         => array( $instance['post'] ),
            'posts_per_page'    => $instance['count'],
            'order'             => $instance['order'],
            'orderby'           => $instance['orderby'],
            'cat'               => $instance['cat'],
            'author'            => $instance['author'],
            'show_thumbnail'    => (bool) $instance['show_thumbnail'],
            'show_author'       => (bool) $instance['show_author'],
            'show_date'         => (bool) $instance['show_date']
        );
        $this->anyposts($query);

        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     *
     * @return void
     */
    public function form( $instance ) {
        $title      = ! empty( $instance['title'] ) ? $instance['title'] : __( '', 'themeaxe' );
        $post       = ! empty( $instance['post'] ) ? $instance['post'] : __( 'post', 'themeaxe' );
        $count      = ! empty( $instance['count'] ) ? $instance['count'] : __( '5', 'themeaxe' );
        $order      = ! empty( $instance['order'] ) ? $instance['order'] : __( 'DESC', 'themeaxe' );
        $orderby    = ! empty( $instance['orderby'] ) ? $instance['orderby'] : __( 'date', 'themeaxe' );
        $category   = ! empty( $instance['cat'] ) ? $instance['cat'] : '';
        $author     = ! empty( $instance['author'] ) ? $instance['author'] : '';
        $show_thumbnail = (bool) $instance['show_thumbnail'];
        $show_author    = (bool) $instance['show_author'];
        $show_date      = (bool) $instance['show_date'];

        // Get all public post types
        $args = array(
            'public'   => true
        );
        $output = "names";
        $operator = "and";
        $post_types = get_post_types( $args, $output, $operator );
        //unset($post_types['attachment']); // Remove 'attachment' from list

        $orderby_list = array(
            'none' => 'None',
            'rand' => 'Random',
            'id' => 'ID',
            'title' => 'Title',
            'name' => 'Slug',
            'date' => 'Date (Default)',
            'modified' => 'Modified date',
            'parent' => 'Parent ID',
            'menu_order' => 'Menu Order',
            'comment_count' => 'Comment Count'
        );

        ?>
        <!-- Widget title -->
        <p class="tap-title">
            <label for="<?php esc_attr_e($this->get_field_id( 'title' )); ?>">
                <?php _e( 'Title:', 'themeaxe' ); ?>
            </label>
            <input class="widefat" id="<?php esc_attr_e($this->get_field_id( 'title' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <!-- Post type -->
        <p class="tap-post">
            <label for="<?php echo esc_attr($this->get_field_id( 'post' )); ?>">
                <?php _e( 'Select post type:', 'themeaxe' ); ?>
            </label>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( 'post' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'post' )); ?>">
                <?php foreach ($post_types as $item=>$val): ?>
                    <option value="<?php esc_attr_e($val); ?>" <?php selected( $val, $post ); ?>>
                        <?php echo ucwords(esc_html($item), "-"); ?>
                    </option>
                <?php endforeach; ?>
                <option value="any" <?php selected( 'any', $post ); ?>>
                    <?php _e('All', 'themeaxe'); ?>
                </option>
            </select>
        </p>

        <!-- Number of posts to show -->
        <p class="tap-count">
            <label for="<?php esc_attr_e($this->get_field_id( 'count' )); ?>">
                <?php _e( 'Number of posts to show:', 'themeaxe' ); ?>
            </label>
            <input class="widefat" id="<?php esc_attr_e($this->get_field_id( 'count' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'count' )); ?>" min="-1" max="100" type="number" value="<?php esc_attr_e( $count ); ?>">
        </p>

        <!-- Thumbnails -->
        <p class="tap-thumbnail">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_thumbnail' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_thumbnail' )); ?>" type="checkbox" value="<?php echo $show_thumbnail; ?>" <?php checked($show_thumbnail); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_thumbnail' )); ?>">
                <?php _e( 'Show thumbnails', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Author -->
        <p class="tap-author">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_author' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_author' )); ?>" type="checkbox" value="<?php echo $show_author; ?>" <?php checked($show_author); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_author' )); ?>">
                <?php _e( 'Show Author', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Date -->
        <p class="tap-date">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_date' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_date' )); ?>" type="checkbox" value="<?php echo $show_date; ?>" <?php checked($show_date); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_date' )); ?>">
                <?php _e( 'Show Date', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Post Order -->
        <p class="tap-order">
            <label for="<?php esc_attr_e($this->get_field_id( 'order' )); ?>">
                <?php _e( 'Order:', 'themeaxe' ); ?>
            </label>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( 'order' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'order' )); ?>">
                <option value="ASC" <?php selected( $order, 'ASC' ); ?>>
                    <?php _e( 'ASC', 'themeaxe' ); ?>
                </option>
                <option value="DESC" <?php selected( $order, 'DESC' ); ?>>
                    <?php _e( 'DESC', 'themeaxe' ); ?>
                </option>
            </select>
        </p>

        <!-- Order By -->
        <p class="tap-orderby">
            <label for="<?php esc_attr_e($this->get_field_id( 'orderby' )); ?>">
                <?php _e( 'Order by:', 'themeaxe' ); ?>
            </label>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( 'orderby' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'orderby' )); ?>">
                <?php foreach ($orderby_list as $key=>$val): ?>
                    <option value="<?php esc_attr_e($key); ?>" <?php selected( $key, $orderby ); ?>>
                        <?php esc_html_e($val); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <!-- Category -->
        <p class="tap-category">
            <label for="<?php esc_attr_e($this->get_field_id( 'cat' )); ?>">
                <?php _e( 'Category:', 'themeaxe' ); ?>
            </label>
            <?php
            $categories = get_terms( 'category', array(
                'orderby'    => 'count',
                'hide_empty' => 0
            ) );
            ?>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( 'cat' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'cat' )); ?>">
                <option value="" <?php selected( '', $category ); ?>>
                    <?php _e('All', 'themeaxe'); ?>
                </option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php esc_attr_e($cat->term_id); ?>" <?php selected( $cat->term_id, $category ); ?>>
                        <?php esc_html_e($cat->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <!-- User -->
        <p class="tap-user">
            <label for="<?php esc_attr_e($this->get_field_id( 'author' )); ?>">
                <?php _e( 'User:', 'themeaxe' ); ?>
            </label>
            <?php
            $blogusers = get_users( array(
                'fields' => array( 'ID', 'display_name' )
            ) );
            ?>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( 'author' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'author' )); ?>">
                <option value="" <?php selected( '', $author ); ?>>
                    <?php _e('All', 'themeaxe'); ?>
                </option>
                <?php foreach ($blogusers as $user): ?>
                    <option value="<?php esc_attr_e($user->ID); ?>" <?php selected( $user->ID, $author ); ?>>
                        <?php esc_html_e($user->display_name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $fields = array('title','post','count','order','orderby', 'cat', 'author');
        foreach ($fields as $field) {
            $instance[$field] = (!empty($new_instance[$field])) ? strip_tags($new_instance[$field]) : '';
        }

        $fields = array('show_thumbnail','show_author','show_date');
        foreach ($fields as $field) {
            $instance[$field] = isset($new_instance[$field])?true:false;
        }

        return $instance;
    }

    /**
     * Post type loop
     * @param $args WP_query objecct
     */
    public function anyposts($args){
        // The Query
        $query = new \WP_Query( $args );

        // The Loop
        if ( $query->have_posts() ): ?>
            <ul class="wp-any-post-list">
                <?php while ( $query->have_posts() ): $query->the_post(); ?>
                <li>
                    <a href='<?php the_permalink(); ?>'>
                        <?php
                            if($args['show_thumbnail']){
                                the_post_thumbnail('thumbnail', ['class' => 'img-responsive wp-any-post-thumbnail', 'title' => get_the_title()]);
                            }
                        ?>
                        <div class="post-title"><?php the_title(); ?></div>
                    </a>
                    <?php if($args['show_author']): ?>
                        <div class="post-author"><?php the_author(); ?></div>
                    <?php endif; ?>
                    <?php if($args['show_date']): ?>
                        <div class="post-date"><?php the_date('j M, Y'); ?></div>
                    <?php endif; ?>
                </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>
                <?php _e("No posts found.", "themeaxe"); ?>
            </p>
        <?php endif;

        // Restore original Post Data
        wp_reset_postdata();
    }
}