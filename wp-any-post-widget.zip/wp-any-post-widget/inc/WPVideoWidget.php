<?php

namespace Themeaxe;

/**
 * Class WPVideoWidget
 * @package Themeaxe
 */
class WPVideoWidget extends \WP_Widget {

    /**
     * WPVideoWidget constructor.
     */
    function __construct() {
        $widget_ops = array(
            'classname' => 'wp_video_widget',
            'description' => __( 'Show uploaded, youtube or vimeo video', 'themeaxe' ),
        );
        parent::__construct( 'wp_video_widget', __('Video', 'themeaxe' ), $widget_ops  );

        add_action('admin_enqueue_scripts', array($this, 'enqueue'));
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];

        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }

        $height = ($instance['height']=='auto')?$instance['height']: intval($instance['height']);
        $width = ($instance['width']=='auto')?$instance['width']: intval($instance['width']);
        $video_external = array(
            'height' => $height,
            'width'  => $width,
            'video_ID'  => $instance['video_ID']
        );
        $video_internal = array(
            'height' => $height,
            'width'  => $width,
            'control'=> $instance['show_control'],
            'autoplay'=> $instance['autoplay'],
            'url'    => $instance['attachment']
        );

        // View
        if($instance['type']=='_youtube' && $instance['video_ID']!=='') {
            $this->youtube_player($video_external);
        }
        else if($instance['type']=='_vimeo' && $instance['video_ID']!=='') {
            $this->vimeo_player($video_external);
        }
        else{
            $this->video_player($video_internal);
        }


        if($instance['caption']!==''): ?>
            <div class="wp-media-widget-caption">
                <?php esc_html_e($instance['caption']); ?>
            </div>
        <?php endif; ?>

        <?php if($instance['description']!==''): ?>
            <div class="wp-media-widget-description">
                <?php esc_html_e($instance['description']); ?>
            </div>
        <?php endif; ?>

        <?php
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     *
     * @return void
     */
    public function form( $instance ) {

        $attachment     = ! empty( $instance['attachment'] ) ? $instance['attachment'] : '';
        $attachment_ID  = ! empty( $instance['attachment_ID'] ) ? $instance['attachment_ID'] : '';

        $action_list = array(
            '_self'     => 'Uploaded video or URL',
            '_youtube'  => 'Youtube',
            '_vimeo'    => 'Vimeo',
            ''          => 'None'
        );
        ?>
        <!-- Widget title -->
        <?php $this->text($instance, 'Title', 'title'); ?>

        <!-- Media -->
        <div class='video-preview-wrapper' <?php if(!$attachment) echo "style='display:none;'"; ?>>
            <h2><div class="dashicons-before dashicons-format-video"></div></h2>
        </div>
        <input data-id="<?php esc_attr_e($attachment_ID); ?>" type="button" class="upload-video-button button" value="<?php _e( 'Add Video', 'themeaxe' ); ?>" />
        <input <?php if(!$attachment) echo "style='display:none;'"; ?> type="button" class="remove-video-button button" value="<?php _e( 'Remove', 'themeaxe' ); ?>" />
        <input class="widefat video-attachment-id" id="<?php esc_attr_e($this->get_field_id( 'attachment_ID' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'attachment_ID' )); ?>" type="hidden" value="<?php echo esc_attr( $attachment_ID ); ?>">

        <!-- Fields -->
        <?php
        $this->text($instance, 'URL', 'attachment');
        $this->select($instance, 'Select video type', 'type', $action_list);
        $this->text($instance, 'Video ID (Youtube or Vimeo)', 'video_ID');
        $this->checkbox($instance, 'Show controls', 'show_control');
        $this->checkbox($instance, 'Autoplay', 'autoplay');
        $this->text($instance, 'Caption', 'caption');
        $this->text($instance, 'Height', 'height', '250');
        $this->text($instance, 'Width', 'width', '250');
        $this->text($instance, 'Description', 'description');
        ?>

        <?php
    }

    /**
     * Text field in widgets
     * @param $instance
     * @param $label
     * @param $field
     * @param $default
     */
    public function text($instance, $label, $field, $default=''){
        $value = ! empty( $instance[$field] ) ? $instance[$field] : $default;
        ?>
        <p class="tap-<?php echo $field; ?>">
            <label for="<?php esc_attr_e($this->get_field_id( $field )); ?>">
                <?php _e( $label.':', 'themeaxe' ); ?>
            </label>
            <input class="widefat" id="<?php esc_attr_e($this->get_field_id( $field )); ?>" name="<?php esc_attr_e($this->get_field_name( $field )); ?>" type="text" value="<?php echo esc_attr( $value ); ?>">
        </p>
        <?php
    }

    /**
     * Select field in widgets
     * @param $instance array Widget instance
     * @param $label string Field label
     * @param $field string Field unique identifier
     * @param $action_list array Option list
     * @param $default string Default selection
     */
    public function select($instance, $label, $field, $action_list, $default=''){
        $value = ! empty( $instance[$field] ) ? $instance[$field] : $default;
        ?>
        <p class="tap-<?php echo $field; ?>">
            <label for="<?php esc_attr_e($this->get_field_id( $field )); ?>">
                <?php _e( $label.':', 'themeaxe' ); ?>
            </label>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( $field )); ?>" name="<?php esc_attr_e($this->get_field_name( $field )); ?>">
                <?php foreach ($action_list as $key=>$val): ?>
                    <option value="<?php esc_attr_e($key); ?>" <?php selected( $key, $value ); ?>>
                        <?php esc_html_e($val); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <?php
    }

    /**
     * Show checkbox
     * @param $instance array
     * @param $label string
     * @param $field string
     * @param bool $default
     */
    public function checkbox($instance, $label, $field){
        $value = (bool) $instance[$field];
        ?>
        <p class="tap-<?php echo $field; ?>">
            <input id="<?php esc_attr_e($this->get_field_id( $field )); ?>" name="<?php esc_attr_e($this->get_field_name( $field )); ?>" type="checkbox" value="<?php echo $value; ?>" <?php checked($value); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( $field )); ?>">
                <?php _e( $label, 'themeaxe' ); ?>
            </label>
        </p>
        <?php
    }

    /**
     * HTML Video player
     * @param $args array Widget instance
     */
    private function video_player($args){
        ?>
        <div class="video" style="width: <?php echo $args['width']; ?>px; height: <?php echo $args['height']; ?>px; overflow: hidden; position: relative;">
            <video width="<?php echo $args['width']; ?>" height="<?php echo $args['height']; ?>" <?php if($args['control']) echo 'controls'; ?> <?php if($args['autoplay']) echo 'autoplay'; ?>>
                <source src="<?php echo $args['url']; ?>">
                Your browser does not support the video tag.
            </video>
        </div>
        <?php
    }

    /**
     * Youtube Video player
     * @param $args array Widget instance
     */
    private function youtube_player($args){
        ?>
        <div class="video" style="width: <?php echo $args['width']; ?>px; height: <?php echo $args['height']; ?>px; overflow: hidden; position: relative;">
            <iframe scrolling="no" seamless="seamless" webkitallowfullscreen="webkitAllowFullScreen"
                    mozallowfullscreen="mozallowfullscreen" allowfullscreen="allowfullscreen"
                    style="position: absolute; top: 0px; left: 0px; width: <?php echo $args['width']; ?>px; height: <?php echo $args['height']; ?>px;"
                    src="http://youtube.com/embed/<?php echo $args['video_ID']; ?>?autoplay=0&loop=0&hd=1&controls=0&showinfo=0&modestbranding=1&iv_load_policy=3&rel=0&playlist=<?php echo $args['Video_ID']; ?>"
                    height="<?php echo $args['height']; ?>" frameborder="0" width="<?php echo $args['width']; ?>">
            </iframe>
        </div>
        <?php
    }

    /**
     * Vimeo Video player
     * @param $args array Widget instance
     */
    private function vimeo_player($args){
        ?>
        <div class="video" style="width: <?php echo $args['width']; ?>px; height: <?php echo $args['height']; ?>px; overflow: hidden; position: relative;">
            <iframe scrolling="no" seamless="seamless" webkitallowfullscreen="webkitAllowFullScreen"
                    mozallowfullscreen="mozallowfullscreen" allowfullscreen="allowfullscreen"
                    src="http://player.vimeo.com/video/<?php echo $args['video_ID']; ?>?api=1&js_api=1&title=0&byline=0&portrait=0&playbar=0&player_id=okplayer&loop=0&autoplay=0"
                    style="position: absolute; top: 0px; left: 0px; width: <?php echo $args['width']; ?>px; height: <?php echo $args['height']; ?>px;" height="<?php echo $args['height']; ?>"
                    frameborder="0" width="<?php echo $args['width']; ?>">
            </iframe>
        </div>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $fields = array('title', 'attachment', 'attachment_ID','caption','height', 'width', 'description', 'type', 'video_ID');

        foreach ($fields as $field) {
            $instance[$field] = (!empty($new_instance[$field])) ? strip_tags($new_instance[$field]) : '';
        }

        $fields = array('show_control', 'autoplay');
        foreach ($fields as $field) {
            $instance[$field] = isset($new_instance[$field])?true:false;
        }

        return $instance;
    }

    /**
     * Enqueue media
     */
    public function enqueue($hook){
        if($hook=='widgets.php'){
            wp_enqueue_media();
            wp_enqueue_script( 'video-explorer', WPAPW_URL.'assets/video-explorer.js' );
        }
    }
}