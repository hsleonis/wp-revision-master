<?php

namespace Themeaxe;

/**
 * Class WPLoginWidget
 * @package Themeaxe
 */
class WPLoginWidget extends \WP_Widget {

    /**
     * WPAnyPost constructor.
     */
    function __construct() {
        $widget_ops = array(
            'classname' => 'wp_login_widget',
            'description' => __( 'Show Login form', 'themeaxe' ),
        );
        parent::__construct( 'wp_login_widget', __('Login', 'themeaxe' ), $widget_ops  );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        if(!is_user_logged_in()) {
            echo $args['before_widget'];

            if (!empty($instance['title'])) {
                echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
            }

            wp_login_form();

            echo $args['after_widget'];
        }
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     *
     * @return void
     */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( '', 'themeaxe' );

        ?>
        <!-- Widget title -->
        <p class="tap-title">
            <label for="<?php esc_attr_e($this->get_field_id( 'title' )); ?>">
                <?php _e( 'Title:', 'themeaxe' ); ?>
            </label>
            <input class="widefat" id="<?php esc_attr_e($this->get_field_id( 'title' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $fields = array('title');

        foreach ($fields as $field) {
            $instance[$field] = (!empty($new_instance[$field])) ? strip_tags($new_instance[$field]) : '';
        }

        return $instance;
    }
}