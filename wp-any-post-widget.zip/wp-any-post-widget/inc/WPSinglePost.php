<?php

namespace Themeaxe;

/**
 * Class WPSinglePost
 * @package Themeaxe
 */
class WPSinglePost extends \WP_Widget {

    /**
     * WPAnyPost constructor.
     */
    function __construct() {
        $widget_ops = array(
            'classname' => 'wp_single_post',
            'description' => __( 'Show any custom post or page', 'themeaxe' ),
        );
        parent::__construct( 'wp_single_post', __('Single Post', 'themeaxe' ), $widget_ops  );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];

        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ). $args['after_title'];
        }

        $this->single($instance);

        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     *
     * @return void
     */
    public function form( $instance ) {
        $title              = ! empty( $instance['title'] ) ? $instance['title'] : __( '', 'themeaxe' );
        $post_ID            = ! empty( $instance['post_ID'] ) ? $instance['post_ID'] : '';
        $show_thumbnail     = (bool) $instance['show_thumbnail'];
        $show_title         = (bool) $instance['show_title'];
        $show_excerpt       = (bool) $instance['show_excerpt'];
        $show_content       = (bool) $instance['show_content'];
        $show_author        = (bool) $instance['show_author'];
        $show_date          = (bool) $instance['show_date'];
        $show_comment       = (bool) $instance['show_comment'];

        // Get all public post types
        $args = array(
            'public'   => true
        );
        $output = "object";
        $operator = "and";
        $post_types = get_post_types( $args, $output, $operator );

        ?>
        <!-- Widget title -->
        <p class="tap-title">
            <label for="<?php esc_attr_e($this->get_field_id( 'title' )); ?>">
                <?php _e( 'Title:', 'themeaxe' ); ?>
            </label>
            <input class="widefat" id="<?php esc_attr_e($this->get_field_id( 'title' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <!-- Post -->
        <p class="tap-post">
            <label for="<?php esc_attr_e($this->get_field_id( 'post_ID' )); ?>">
                <?php _e( 'Select post', 'themeaxe' ); ?>
            </label>
            <select class="widefat" id="<?php esc_attr_e($this->get_field_id( 'post_ID' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'post_ID' )); ?>" required>
                <?php foreach ($post_types as $type): ?>
                <optgroup label="<?php echo $type->label; ?>">
                    <?php $args = array(
                        'post_type'     => $type->name,
                        'post_status'   => 'publish',
                        'nopaging'      => true,
                        'orderby'       => 'title',
                        'order'         => 'ASC'
                    );
                    // The Query
                    $query = new \WP_Query( $args );
                    if($query->have_posts()):
                        while ($query->have_posts()): $query->the_post();
                    ?>
                            <option value="<?php the_ID(); ?>" <?php selected( get_the_ID(), $post_ID ); ?>>
                                <?php the_title(); ?>
                            </option>
                    <?php
                        endwhile;
                        wp_reset_postdata();
                        flush();
                    else:
                    ?>
                        <option disabled>
                            <?php _e('No posts', 'themeaxe'); ?>
                        </option>
                    <?php
                        endif;
                    ?>
                </optgroup>
                <?php endforeach; ?>
            </select>
        </p>

        <!-- Description -->
        <p class="tap-description">
            <strong><?php _e( 'Select elements to show.', 'themeaxe' ); ?></strong>
        </p>

        <!-- Thumbnails -->
        <p class="tap-thumbnail">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_thumbnail' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_thumbnail' )); ?>" type="checkbox" value="<?php echo $show_thumbnail; ?>" <?php checked($show_thumbnail); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_thumbnail' )); ?>">
                <?php _e( 'Thumbnail', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Post title -->
        <p class="tap-post-title">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_title' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_title' )); ?>" type="checkbox" value="<?php echo $show_title; ?>" <?php checked($show_title); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_title' )); ?>">
                <?php _e( 'Title', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Author -->
        <p class="tap-author">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_author' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_author' )); ?>" type="checkbox" value="<?php echo $show_author; ?>" <?php checked($show_author); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_author' )); ?>">
                <?php _e( 'Author', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Date -->
        <p class="tap-date">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_date' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_date' )); ?>" type="checkbox" value="<?php echo $show_date; ?>" <?php checked($show_date); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_date' )); ?>">
                <?php _e( 'Date', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Excerpt -->
        <p class="tap-excerpt">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_excerpt' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_excerpt' )); ?>" type="checkbox" value="<?php echo $show_excerpt; ?>" <?php checked($show_excerpt); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_excerpt' )); ?>">
                <?php _e( 'Excerpt', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Content -->
        <p class="tap-contant">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_content' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_content' )); ?>" type="checkbox" value="<?php echo $show_content; ?>" <?php checked($show_content); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_content' )); ?>">
                <?php _e( 'Content', 'themeaxe' ); ?>
            </label>
        </p>

        <!-- Comment -->
        <p class="tap-comment">
            <input id="<?php esc_attr_e($this->get_field_id( 'show_comment' )); ?>" name="<?php esc_attr_e($this->get_field_name( 'show_comment' )); ?>" type="checkbox" value="<?php echo $show_comment; ?>" <?php checked($show_comment); ?>>
            <label for="<?php esc_attr_e($this->get_field_id( 'show_comment' )); ?>">
                <?php _e( 'Comment Count', 'themeaxe' ); ?>
            </label>
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $fields = array('title','post_ID');
        foreach ($fields as $field) {
            $instance[$field] = (!empty($new_instance[$field])) ? strip_tags($new_instance[$field]) : '';
        }

        $fields = array('show_title','show_thumbnail','show_excerpt','show_content','show_author','show_date','show_comment');
        foreach ($fields as $field) {
            $instance[$field] = isset($new_instance[$field])?true:false;
        }

        return $instance;
    }

    /**
     * Single post
     * @param $args WP_query objecct
     */
    public function single($data){
        // Get post by ID
        $post = get_post( $data['post_ID'] );

        // The post
        if ( $post): ?>
            <div class="wp-any-post-single">
                <?php if($data['show_thumbnail']): ?>
                    <a href="<?php echo get_permalink( $post->ID ); ?>">
                    <?php echo get_the_post_thumbnail($post->ID, 'thumbnail', ['class' => 'img-responsive wp-any-post-thumbnail', 'title' => $post->post_title]); ?>
                    </a>
                <?php endif; ?>
                <?php if($data['show_title']): ?>
                    <div class="post-title">
                        <a href="<?php echo get_permalink( $post->ID ); ?>">
                            <?php esc_html_e($post->post_title); ?>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($data['show_author']): ?>
                    <div class="post-author">
                        <a href="<?php echo get_author_posts_url( $post->post_author ); ?>">
                            <?php echo get_user_by('id', $post->post_author)->display_name; ?>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if($data['show_date']): ?>
                    <div class="post-date"><?php esc_html_e(date('d M, Y',strtotime($post->post_date))); ?></div>
                <?php endif; ?>
                <?php if($data['show_content']): ?>
                    <div class="post-content"><?php echo do_shortcode($post->post_content); ?></div>
                <?php endif; ?>
                <?php if($data['show_excerpt']): ?>
                    <div class="post-excerpt"><?php esc_html_e($post->post_excerpt); ?></div>
                <?php endif; ?>
                <?php if($data['show_comment']): ?>
                    <div class="post-comment"><?php echo __('Comments:', 'themeaxe') . esc_html__($post->comment_count); ?></div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p>
                <?php _e("Post not found.", "themeaxe"); ?>
            </p>
        <?php endif;
    }

}